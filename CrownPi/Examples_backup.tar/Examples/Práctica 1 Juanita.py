
texto1="Bienvenido a python"
activo=True
calificación=8.1
texto2="Feliz día"
print(18)
print("Bienvenido a python")
edad=20
print(edad)
palabra1=10
palabra2=50
print(palabra1+palabra2)
numero1=10
numero2=50
print(numero1+numero2)
print(numero1-numero2)
print(numero1*numero2)
print(numero1/numero2)
frase1="El resultado es:"

print(frase1,+numero2)

lado=30
unidad="mm"
print("resultado es :",lado*lado,unidad)

lado=30
unidad="mm"
resultado=lado*lado
print("El resultado es:",resultado,unidad)
