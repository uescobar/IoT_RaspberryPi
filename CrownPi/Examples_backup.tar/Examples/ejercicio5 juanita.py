cuenta=0
while cuenta <=100:
    print(cuenta)
    #cuenta=cuenta+1
    cuenta+=1
    
#nombres=["hugo","luis"]    
for n in range(8):
    print(n+1)
    

