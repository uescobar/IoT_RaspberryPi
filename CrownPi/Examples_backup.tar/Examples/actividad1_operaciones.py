print("calcular area de triangulo")
base=15
altura=12
unidad="mm"
resultado=base*altura/2
print("el resultado es",resultado)

x=float(input("Escribe un numero:"))
y=int(input("Escribe otro numero:"))
print(x+y)






