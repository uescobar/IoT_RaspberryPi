numero=10
numero2=20
print("hola",numero)
print("adios", numero)
print("hola",numero)
"""
Descripción:Este programa es de ejemplo para mostrar el uso de comentarios.
"""
print("""
      Bienvenido a la calculadora
      Selecciona una opción:
      a)suma
      b)resta
      c)multi
      """)
