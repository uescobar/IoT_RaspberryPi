
if 8==8:
    print("Es valido")
    print("Es igual a 8")
elif 10==11:
    print("Es valido 2")    
else:
    print("no es valido")

print("fin del programa")
print("fin del programa")